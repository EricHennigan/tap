#!/bin/sh

cat ./kateschemarc.darkoxygen >> ~/.kde/share/config/kateschemarc
cat ./katesyntaxhighlightingrc.darkoxygen >> ~/.kde/share/config/katesyntaxhighlightingrc
